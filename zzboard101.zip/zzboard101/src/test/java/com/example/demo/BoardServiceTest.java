package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dto.BoardDto.DeleteDto;
import com.example.demo.dto.BoardDto.UpdateDto;
import com.example.demo.dto.BoardDto.WriteDto;
import com.example.demo.entity.Board;
import com.example.demo.service.BoardService;

@SpringBootTest
public class BoardServiceTest {
	@Autowired
	BoardService service;
	
	@Transactional
	//@Test
	public void writeTest() {
		WriteDto dto = WriteDto.builder().title("xxx").content("yyy").writer("friday").password("1111").build();
		Board result = service.save(dto);
		assertEquals(2, result.getBno());
	}
	
	//@Test
	public void readTest() {
		System.out.println(service.findById(1));
		assertEquals(true, service.findById(1).isPresent());
		assertEquals(true, service.findById(1111).isEmpty());
	}
	
	//@Test
	public void updateTest() {
		UpdateDto ud = UpdateDto.builder().title("aaa").content("bbb").bno(1).password("1111").build();
		assertEquals(true, service.update(ud));
	}
	
	@Transactional
	@Test
	public void deleteTest() {
		DeleteDto d1 = DeleteDto.builder().bno(470).password("1234").build();
		DeleteDto d2 = DeleteDto.builder().bno(1).password("1234").build();
		DeleteDto d3 = DeleteDto.builder().bno(1).password("1111").build();
		assertEquals(false, service.delteById(d1));
		assertEquals(false, service.delteById(d2));
		assertEquals(true, service.delteById(d3));
	}
}
