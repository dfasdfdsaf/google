package com.example.demo.entity;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
public class Board {
	private Integer bno;
	private String title;
	private String content;
	private String writer;
	private String password;
	private LocalDateTime writeTime;
	private Integer readCnt;
}
