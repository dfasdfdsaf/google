package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BoardDao;
import com.example.demo.dto.BoardDto;
import com.example.demo.dto.BoardDto.DeleteDto;
import com.example.demo.dto.BoardDto.UpdateDto;
import com.example.demo.dto.BoardDto.WriteDto;
import com.example.demo.entity.Board;

@Service
public class BoardService {
	@Autowired
	private BoardDao dao;
	
	public List<BoardDto.ListDto> findAll() {
		return dao.findAll();
	}
	
	public Optional<BoardDto.ReadDto> findById(Integer bno) {
		dao.increaseReadCnt(bno);
		Optional<BoardDto.ReadDto> result = dao.findById(bno);
		return result;
	}
	
	public Board save(WriteDto dto) {
		Board board = dto.toEntity();
		dao.save(board);
		return board;
	}
	
	public boolean update(UpdateDto dto) {
		Optional<String> result = dao.findPassword(dto.getBno());
		if(result.isEmpty())
			return false;
		if(result.get().equals(dto.getPassword())==false)
			return false;
		dao.update(dto.toEntity());
		return true;
	}
	
	public boolean delteById(DeleteDto dto) {
		Optional<String> result = dao.findPassword(dto.getBno());
		if(result.isEmpty())
			return false;
		if(result.get().equals(dto.getPassword())==false)
			return false;
		dao.deleteById(dto.getBno());
		return true;
	}
}
